import { View, Text, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
import { StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Mic, Play, Pause, RotateCcw, Volume2, Award, Zap, Target } from 'lucide-react-native';
import Animated, { FadeInDown, FadeInUp, useSharedValue, useAnimatedStyle, withSpring, withRepeat, withSequence } from 'react-native-reanimated';
import { useEffect, useState } from 'react';

const { width } = Dimensions.get('window');

const practiceTypes = [
  {
    id: 1,
    title: 'Pronunciation',
    description: 'Perfect your accent',
    icon: Mic,
    color: ['#00D4AA', '#4ECDC4'],
    exercises: 25,
    type: 'speaking',
  },
  {
    id: 2,
    title: 'Listening',
    description: 'Train your ear',
    icon: Volume2,
    color: ['#667EEA', '#764BA2'],
    exercises: 30,
    type: 'listening',
  },
  {
    id: 3,
    title: 'Comparison',
    description: 'Spot differences',
    icon: Target,
    color: ['#F093FB', '#F5576C'],
    exercises: 20,
    type: 'comparison',
  },
];

const recentPractice = [
  { language: 'Spanish', score: 95, time: '5 min ago' },
  { language: 'French', score: 87, time: '1 hour ago' },
  { language: 'German', score: 92, time: '2 hours ago' },
];

export default function PracticeScreen() {
  const [isRecording, setIsRecording] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const pulseValue = useSharedValue(1);
  const waveValue = useSharedValue(0);

  useEffect(() => {
    if (isRecording) {
      pulseValue.value = withRepeat(
        withSequence(
          withSpring(1.1, { duration: 500 }),
          withSpring(1, { duration: 500 })
        ),
        -1,
        true
      );
      waveValue.value = withRepeat(
        withSpring(1, { duration: 800 }),
        -1,
        true
      );
    } else {
      pulseValue.value = withSpring(1);
      waveValue.value = withSpring(0);
    }
  }, [isRecording]);

  const pulseStyle = useAnimatedStyle(() => ({
    transform: [{ scale: pulseValue.value }],
  }));

  const waveStyle = useAnimatedStyle(() => ({
    opacity: waveValue.value,
    transform: [{ scale: 1 + waveValue.value * 0.5 }],
  }));

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#1F2937', '#374151', '#4B5563']}
        style={styles.gradient}>
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
          
          {/* Header */}
          <Animated.View entering={FadeInDown.delay(100)} style={styles.header}>
            <Text style={styles.title}>Practice Hub</Text>
            <Text style={styles.subtitle}>Improve your pronunciation</Text>
          </Animated.View>

          {/* Daily Challenge */}
          <Animated.View entering={FadeInUp.delay(200)} style={styles.challengeSection}>
            <LinearGradient
              colors={['#00D4AA', '#4ECDC4']}
              style={styles.challengeCard}>
              <View style={styles.challengeOverlay}>
                <View style={styles.challengeHeader}>
                  <Award size={24} color="#FFFFFF" strokeWidth={2} />
                  <Text style={styles.challengeTitle}>Daily Challenge</Text>
                </View>
                <Text style={styles.challengeDescription}>
                  Practice the 'TH' sound in English
                </Text>
                <View style={styles.challengeProgress}>
                  <Text style={styles.challengeProgressText}>Progress: 3/5</Text>
                  <View style={styles.challengeProgressBar}>
                    <View style={styles.challengeProgressBackground} />
                    <View style={[styles.challengeProgressFill, { width: '60%' }]} />
                  </View>
                </View>
                <TouchableOpacity style={styles.challengeButton}>
                  <Text style={styles.challengeButtonText}>Continue</Text>
                  <Zap size={16} color="#00D4AA" strokeWidth={2} />
                </TouchableOpacity>
              </View>
            </LinearGradient>
          </Animated.View>

          {/* Voice Recorder */}
          <Animated.View entering={FadeInDown.delay(300)} style={styles.recorderSection}>
            <LinearGradient
              colors={['#F8F9FA', '#E9ECEF']}
              style={styles.recorderCard}>
              <Text style={styles.recorderTitle}>Voice Practice</Text>
              <Text style={styles.recorderSubtitle}>Say: "The thirty-three thieves"</Text>
              
              <View style={styles.recorderVisualizer}>
                {isRecording && (
                  <>
                    <Animated.View style={[styles.waveRing, styles.waveRing1, waveStyle]} />
                    <Animated.View style={[styles.waveRing, styles.waveRing2, waveStyle]} />
                    <Animated.View style={[styles.waveRing, styles.waveRing3, waveStyle]} />
                  </>
                )}
                <Animated.View style={[styles.recorderButton, pulseStyle]}>
                  <TouchableOpacity
                    onPress={() => setIsRecording(!isRecording)}
                    style={styles.recorderButtonInner}>
                    <LinearGradient
                      colors={isRecording ? ['#EF4444', '#DC2626'] : ['#00D4AA', '#4ECDC4']}
                      style={styles.recorderButtonGradient}>
                      {isRecording ? (
                        <Pause size={32} color="#FFFFFF" strokeWidth={2} />
                      ) : (
                        <Mic size={32} color="#FFFFFF" strokeWidth={2} />
                      )}
                    </LinearGradient>
                  </TouchableOpacity>
                </Animated.View>
              </View>

              <View style={styles.recorderControls}>
                <TouchableOpacity style={styles.controlButton}>
                  <RotateCcw size={20} color="#6B7280" strokeWidth={2} />
                  <Text style={styles.controlButtonText}>Reset</Text>
                </TouchableOpacity>
                <TouchableOpacity 
                  style={styles.controlButton}
                  onPress={() => setIsPlaying(!isPlaying)}>
                  {isPlaying ? (
                    <Pause size={20} color="#6B7280" strokeWidth={2} />
                  ) : (
                    <Play size={20} color="#6B7280" strokeWidth={2} />
                  )}
                  <Text style={styles.controlButtonText}>
                    {isPlaying ? 'Pause' : 'Play'}
                  </Text>
                </TouchableOpacity>
              </View>
            </LinearGradient>
          </Animated.View>

          {/* Practice Types */}
          <Animated.View entering={FadeInDown.delay(400)} style={styles.section}>
            <Text style={styles.sectionTitle}>Practice Types</Text>
            <View style={styles.practiceGrid}>
              {practiceTypes.map((type, index) => (
                <Animated.View
                  key={type.id}
                  entering={FadeInDown.delay(450 + index * 100)}
                  style={styles.practiceCard}>
                  <TouchableOpacity>
                    <LinearGradient
                      colors={type.color}
                      style={styles.practiceGradient}>
                      <View style={styles.practiceOverlay}>
                        <View style={styles.practiceIconContainer}>
                          <type.icon size={24} color="#FFFFFF" strokeWidth={2} />
                        </View>
                        <Text style={styles.practiceTitle}>{type.title}</Text>
                        <Text style={styles.practiceDescription}>{type.description}</Text>
                        <Text style={styles.practiceExercises}>
                          {type.exercises} exercises
                        </Text>
                      </View>
                    </LinearGradient>
                  </TouchableOpacity>
                </Animated.View>
              ))}
            </View>
          </Animated.View>

          {/* Recent Practice */}
          <Animated.View entering={FadeInDown.delay(700)} style={styles.section}>
            <Text style={styles.sectionTitle}>Recent Practice</Text>
            <View style={styles.recentList}>
              {recentPractice.map((practice, index) => (
                <Animated.View
                  key={practice.language}
                  entering={FadeInDown.delay(750 + index * 100)}
                  style={styles.recentCard}>
                  <LinearGradient
                    colors={['#F8F9FA', '#E9ECEF']}
                    style={styles.recentGradient}>
                    <View style={styles.recentContent}>
                      <View style={styles.recentInfo}>
                        <Text style={styles.recentLanguage}>{practice.language}</Text>
                        <Text style={styles.recentTime}>{practice.time}</Text>
                      </View>
                      <View style={styles.recentScore}>
                        <Text style={styles.recentScoreText}>{practice.score}%</Text>
                        <View style={[
                          styles.recentScoreBadge,
                          practice.score >= 90 ? styles.excellentBadge :
                          practice.score >= 80 ? styles.goodBadge : styles.okBadge
                        ]}>
                          <Text style={[
                            styles.recentScoreBadgeText,
                            practice.score >= 90 ? styles.excellentText :
                            practice.score >= 80 ? styles.goodText : styles.okText
                          ]}>
                            {practice.score >= 90 ? 'Excellent' :
                             practice.score >= 80 ? 'Good' : 'Keep Practicing'}
                          </Text>
                        </View>
                      </View>
                    </View>
                  </LinearGradient>
                </Animated.View>
              ))}
            </View>
          </Animated.View>

          <View style={styles.bottomPadding} />
        </ScrollView>
      </LinearGradient>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1F2937',
  },
  gradient: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 20,
  },
  header: {
    paddingTop: 16,
    paddingBottom: 24,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Poppins-Bold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
  },
  challengeSection: {
    marginBottom: 32,
  },
  challengeCard: {
    borderRadius: 20,
    overflow: 'hidden',
    minHeight: 140,
  },
  challengeOverlay: {
    flex: 1,
    padding: 24,
  },
  challengeHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
  },
  challengeTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: '#FFFFFF',
  },
  challengeDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#FFFFFF',
    opacity: 0.9,
    marginBottom: 16,
  },
  challengeProgress: {
    marginBottom: 16,
  },
  challengeProgressText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#FFFFFF',
    opacity: 0.8,
    marginBottom: 8,
  },
  challengeProgressBar: {
    position: 'relative',
    height: 4,
  },
  challengeProgressBackground: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    borderRadius: 2,
  },
  challengeProgressFill: {
    height: '100%',
    backgroundColor: '#FFFFFF',
    borderRadius: 2,
  },
  challengeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 12,
    gap: 4,
  },
  challengeButtonText: {
    fontSize: 14,
    fontFamily: 'Poppins-SemiBold',
    color: '#00D4AA',
  },
  recorderSection: {
    marginBottom: 32,
  },
  recorderCard: {
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
  },
  recorderTitle: {
    fontSize: 20,
    fontFamily: 'Poppins-SemiBold',
    color: '#1F2937',
    marginBottom: 4,
  },
  recorderSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginBottom: 32,
  },
  recorderVisualizer: {
    position: 'relative',
    width: 120,
    height: 120,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 32,
  },
  waveRing: {
    position: 'absolute',
    borderWidth: 2,
    borderColor: '#00D4AA',
    borderRadius: 60,
  },
  waveRing1: {
    width: 80,
    height: 80,
  },
  waveRing2: {
    width: 100,
    height: 100,
  },
  waveRing3: {
    width: 120,
    height: 120,
  },
  recorderButton: {
    width: 80,
    height: 80,
    borderRadius: 40,
    overflow: 'hidden',
  },
  recorderButtonInner: {
    flex: 1,
  },
  recorderButtonGradient: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  recorderControls: {
    flexDirection: 'row',
    gap: 24,
  },
  controlButton: {
    alignItems: 'center',
    gap: 4,
  },
  controlButtonText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Poppins-SemiBold',
    color: '#FFFFFF',
    marginBottom: 16,
  },
  practiceGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  practiceCard: {
    flex: 1,
    borderRadius: 16,
    overflow: 'hidden',
  },
  practiceGradient: {
    minHeight: 140,
  },
  practiceOverlay: {
    flex: 1,
    padding: 16,
    backgroundColor: 'rgba(0, 0, 0, 0.1)',
  },
  practiceIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  practiceTitle: {
    fontSize: 16,
    fontFamily: 'Poppins-SemiBold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  practiceDescription: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#FFFFFF',
    opacity: 0.9,
    marginBottom: 8,
  },
  practiceExercises: {
    fontSize: 11,
    fontFamily: 'Inter-Medium',
    color: '#FFFFFF',
    opacity: 0.8,
  },
  recentList: {
    gap: 12,
  },
  recentCard: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  recentGradient: {
    padding: 16,
  },
  recentContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  recentInfo: {
    flex: 1,
  },
  recentLanguage: {
    fontSize: 16,
    fontFamily: 'Poppins-SemiBold',
    color: '#1F2937',
    marginBottom: 4,
  },
  recentTime: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  recentScore: {
    alignItems: 'flex-end',
  },
  recentScoreText: {
    fontSize: 18,
    fontFamily: 'Poppins-Bold',
    color: '#00D4AA',
    marginBottom: 4,
  },
  recentScoreBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 6,
  },
  excellentBadge: {
    backgroundColor: '#D1FAE5',
  },
  goodBadge: {
    backgroundColor: '#DBEAFE',
  },
  okBadge: {
    backgroundColor: '#FEF3C7',
  },
  recentScoreBadgeText: {
    fontSize: 10,
    fontFamily: 'Inter-SemiBold',
  },
  excellentText: {
    color: '#065F46',
  },
  goodText: {
    color: '#1E40AF',
  },
  okText: {
    color: '#92400E',
  },
  bottomPadding: {
    height: 20,
  },
});