import { View, Text, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
import { StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { 
  Settings, 
  Award, 
  Calendar, 
  TrendingUp, 
  Star, 
  Clock, 
  Target,
  Globe,
  BookOpen,
  Mic,
  ChevronRight
} from 'lucide-react-native';
import Animated, { FadeInDown, FadeInUp } from 'react-native-reanimated';

const achievements = [
  { id: 1, title: 'First Steps', description: 'Complete your first lesson', earned: true },
  { id: 2, title: 'Pronunciation Pro', description: 'Master 10 pronunciation exercises', earned: true },
  { id: 3, title: 'Weekly Warrior', description: 'Practice 7 days in a row', earned: false },
  { id: 4, title: 'Polyglot', description: 'Study 3 different languages', earned: false },
];

const stats = [
  { icon: Clock, label: 'Total Study Time', value: '24h 32m', color: '#00D4AA' },
  { icon: Calendar, label: 'Current Streak', value: '12 days', color: '#667EEA' },
  { icon: Target, label: 'Lessons Completed', value: '47', color: '#F093FB' },
  { icon: Award, label: 'Achievements', value: '2/4', color: '#FFA726' },
];

const languages = [
  { name: 'Spanish', progress: 75, level: 'Intermediate' },
  { name: 'French', progress: 45, level: 'Beginner' },
  { name: 'German', progress: 30, level: 'Beginner' },
];

const menuItems = [
  { icon: Settings, title: 'Settings', subtitle: 'App preferences' },
  { icon: Award, title: 'Achievements', subtitle: 'View all badges' },
  { icon: TrendingUp, title: 'Progress Report', subtitle: 'Detailed analytics' },
  { icon: Globe, title: 'Languages', subtitle: 'Manage your languages' },
];

export default function ProfileScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#1F2937', '#374151', '#4B5563']}
        style={styles.gradient}>
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
          
          {/* Header */}
          <Animated.View entering={FadeInDown.delay(100)} style={styles.header}>
            <Text style={styles.title}>Profile</Text>
            <TouchableOpacity style={styles.settingsButton}>
              <Settings size={24} color="#9CA3AF" strokeWidth={2} />
            </TouchableOpacity>
          </Animated.View>

          {/* Profile Card */}
          <Animated.View entering={FadeInUp.delay(200)} style={styles.profileSection}>
            <LinearGradient
              colors={['#00D4AA', '#4ECDC4']}
              style={styles.profileCard}>
              <View style={styles.profileOverlay}>
                <View style={styles.profileAvatar}>
                  <LinearGradient
                    colors={['#FFFFFF', '#F3F4F6']}
                    style={styles.avatarGradient}>
                    <Text style={styles.avatarText}>U</Text>
                  </LinearGradient>
                </View>
                <Text style={styles.profileName}>Language Learner</Text>
                <Text style={styles.profileEmail}>learner@example.com</Text>
                <View style={styles.profileStats}>
                  <View style={styles.profileStat}>
                    <Star size={16} color="#FFFFFF" strokeWidth={2} />
                    <Text style={styles.profileStatText}>Level 3</Text>
                  </View>
                  <View style={styles.profileStatDivider} />
                  <View style={styles.profileStat}>
                    <Globe size={16} color="#FFFFFF" strokeWidth={2} />
                    <Text style={styles.profileStatText}>3 Languages</Text>
                  </View>
                </View>
              </View>
            </LinearGradient>
          </Animated.View>

          {/* Stats Grid */}
          <Animated.View entering={FadeInDown.delay(300)} style={styles.statsSection}>
            <View style={styles.statsGrid}>
              {stats.map((stat, index) => (
                <Animated.View
                  key={stat.label}
                  entering={FadeInDown.delay(350 + index * 50)}
                  style={styles.statCard}>
                  <LinearGradient
                    colors={['#F8F9FA', '#E9ECEF']}
                    style={styles.statGradient}>
                    <View style={[styles.statIcon, { backgroundColor: `${stat.color}20` }]}>
                      <stat.icon size={20} color={stat.color} strokeWidth={2} />
                    </View>
                    <Text style={styles.statValue}>{stat.value}</Text>
                    <Text style={styles.statLabel}>{stat.label}</Text>
                  </LinearGradient>
                </Animated.View>
              ))}
            </View>
          </Animated.View>

          {/* Language Progress */}
          <Animated.View entering={FadeInDown.delay(500)} style={styles.section}>
            <Text style={styles.sectionTitle}>Language Progress</Text>
            <View style={styles.languagesList}>
              {languages.map((language, index) => (
                <Animated.View
                  key={language.name}
                  entering={FadeInDown.delay(550 + index * 100)}
                  style={styles.languageCard}>
                  <LinearGradient
                    colors={['#F8F9FA', '#E9ECEF']}
                    style={styles.languageGradient}>
                    <View style={styles.languageHeader}>
                      <View style={styles.languageInfo}>
                        <Text style={styles.languageName}>{language.name}</Text>
                        <Text style={styles.languageLevel}>{language.level}</Text>
                      </View>
                      <Text style={styles.languageProgress}>{language.progress}%</Text>
                    </View>
                    <View style={styles.progressBarContainer}>
                      <View style={styles.progressBarBackground} />
                      <LinearGradient
                        colors={['#00D4AA', '#4ECDC4']}
                        style={[styles.progressBarFill, { width: `${language.progress}%` }]}
                      />
                    </View>
                  </LinearGradient>
                </Animated.View>
              ))}
            </View>
          </Animated.View>

          {/* Achievements */}
          <Animated.View entering={FadeInDown.delay(700)} style={styles.section}>
            <Text style={styles.sectionTitle}>Recent Achievements</Text>
            <View style={styles.achievementsList}>
              {achievements.slice(0, 2).map((achievement, index) => (
                <Animated.View
                  key={achievement.id}
                  entering={FadeInDown.delay(750 + index * 100)}
                  style={styles.achievementCard}>
                  <LinearGradient
                    colors={achievement.earned ? ['#00D4AA', '#4ECDC4'] : ['#F8F9FA', '#E9ECEF']}
                    style={styles.achievementGradient}>
                    <View style={styles.achievementContent}>
                      <View style={styles.achievementIcon}>
                        <Award 
                          size={20} 
                          color={achievement.earned ? '#FFFFFF' : '#6B7280'} 
                          strokeWidth={2} 
                        />
                      </View>
                      <View style={styles.achievementInfo}>
                        <Text style={[
                          styles.achievementTitle,
                          { color: achievement.earned ? '#FFFFFF' : '#1F2937' }
                        ]}>
                          {achievement.title}
                        </Text>
                        <Text style={[
                          styles.achievementDescription,
                          { color: achievement.earned ? '#FFFFFF' : '#6B7280', opacity: achievement.earned ? 0.9 : 1 }
                        ]}>
                          {achievement.description}
                        </Text>
                      </View>
                      {achievement.earned && (
                        <View style={styles.achievementBadge}>
                          <Text style={styles.achievementBadgeText}>✓</Text>
                        </View>
                      )}
                    </View>
                  </LinearGradient>
                </Animated.View>
              ))}
            </View>
          </Animated.View>

          {/* Menu Items */}
          <Animated.View entering={FadeInDown.delay(900)} style={styles.section}>
            <Text style={styles.sectionTitle}>More Options</Text>
            <View style={styles.menuList}>
              {menuItems.map((item, index) => (
                <Animated.View
                  key={item.title}
                  entering={FadeInDown.delay(950 + index * 50)}
                  style={styles.menuCard}>
                  <TouchableOpacity>
                    <LinearGradient
                      colors={['#F8F9FA', '#E9ECEF']}
                      style={styles.menuGradient}>
                      <View style={styles.menuContent}>
                        <View style={styles.menuIcon}>
                          <item.icon size={20} color="#00D4AA" strokeWidth={2} />
                        </View>
                        <View style={styles.menuInfo}>
                          <Text style={styles.menuTitle}>{item.title}</Text>
                          <Text style={styles.menuSubtitle}>{item.subtitle}</Text>
                        </View>
                        <ChevronRight size={20} color="#9CA3AF" strokeWidth={2} />
                      </View>
                    </LinearGradient>
                  </TouchableOpacity>
                </Animated.View>
              ))}
            </View>
          </Animated.View>

          <View style={styles.bottomPadding} />
        </ScrollView>
      </LinearGradient>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1F2937',
  },
  gradient: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 16,
    paddingBottom: 24,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Poppins-Bold',
    color: '#FFFFFF',
  },
  settingsButton: {
    padding: 8,
  },
  profileSection: {
    marginBottom: 32,
  },
  profileCard: {
    borderRadius: 20,
    overflow: 'hidden',
  },
  profileOverlay: {
    padding: 24,
    alignItems: 'center',
  },
  profileAvatar: {
    marginBottom: 16,
  },
  avatarGradient: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    fontSize: 28,
    fontFamily: 'Poppins-Bold',
    color: '#00D4AA',
  },
  profileName: {
    fontSize: 20,
    fontFamily: 'Poppins-Bold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  profileEmail: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#FFFFFF',
    opacity: 0.8,
    marginBottom: 16,
  },
  profileStats: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  profileStat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  profileStatText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#FFFFFF',
  },
  profileStatDivider: {
    width: 1,
    height: 16,
    backgroundColor: '#FFFFFF',
    opacity: 0.3,
  },
  statsSection: {
    marginBottom: 32,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  statCard: {
    width: '48%',
    borderRadius: 16,
    overflow: 'hidden',
  },
  statGradient: {
    padding: 16,
    alignItems: 'center',
    gap: 8,
  },
  statIcon: {
    width: 40,
    height: 40,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  statValue: {
    fontSize: 18,
    fontFamily: 'Poppins-Bold',
    color: '#1F2937',
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    textAlign: 'center',
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Poppins-SemiBold',
    color: '#FFFFFF',
    marginBottom: 16,
  },
  languagesList: {
    gap: 12,
  },
  languageCard: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  languageGradient: {
    padding: 16,
  },
  languageHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  languageInfo: {
    flex: 1,
  },
  languageName: {
    fontSize: 16,
    fontFamily: 'Poppins-SemiBold',
    color: '#1F2937',
    marginBottom: 2,
  },
  languageLevel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  languageProgress: {
    fontSize: 16,
    fontFamily: 'Poppins-Bold',
    color: '#00D4AA',
  },
  progressBarContainer: {
    position: 'relative',
    height: 6,
  },
  progressBarBackground: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    backgroundColor: '#E5E7EB',
    borderRadius: 3,
  },
  progressBarFill: {
    height: '100%',
    borderRadius: 3,
  },
  achievementsList: {
    gap: 12,
  },
  achievementCard: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  achievementGradient: {
    padding: 16,
  },
  achievementContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  achievementIcon: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  achievementInfo: {
    flex: 1,
  },
  achievementTitle: {
    fontSize: 16,
    fontFamily: 'Poppins-SemiBold',
    marginBottom: 2,
  },
  achievementDescription: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
  },
  achievementBadge: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  achievementBadgeText: {
    fontSize: 12,
    fontFamily: 'Poppins-Bold',
    color: '#FFFFFF',
  },
  menuList: {
    gap: 12,
  },
  menuCard: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  menuGradient: {
    padding: 16,
  },
  menuContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  menuIcon: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: '#E0F2FE',
    justifyContent: 'center',
    alignItems: 'center',
  },
  menuInfo: {
    flex: 1,
  },
  menuTitle: {
    fontSize: 16,
    fontFamily: 'Poppins-SemiBold',
    color: '#1F2937',
    marginBottom: 2,
  },
  menuSubtitle: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  bottomPadding: {
    height: 20,
  },
});