import { View, Text, ScrollView, TouchableOpacity, Image, Dimensions } from 'react-native';
import { StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Play, Star, Clock, Users, Globe, TrendingUp } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import Animated, { FadeInDown, FadeInUp, useSharedValue, useAnimatedStyle, withSpring, withRepeat, withSequence } from 'react-native-reanimated';
import { useEffect } from 'react';

const { width } = Dimensions.get('window');

const languages = [
  { name: 'Spanish', flag: '🇪🇸', speakers: '500M+', difficulty: 'Beginner' },
  { name: 'French', flag: '🇫🇷', speakers: '280M+', difficulty: 'Intermediate' },
  { name: 'German', flag: '🇩🇪', speakers: '130M+', difficulty: 'Intermediate' },
  { name: 'Japanese', flag: '🇯🇵', speakers: '125M+', difficulty: 'Advanced' },
  { name: 'Mandarin', flag: '🇨🇳', speakers: '1.1B+', difficulty: 'Advanced' },
  { name: 'Italian', flag: '🇮🇹', speakers: '65M+', difficulty: 'Beginner' },
];

const features = [
  { icon: Globe, title: 'Global Languages', desc: 'Learn from 50+ languages' },
  { icon: Users, title: 'Native Speakers', desc: 'Practice with real people' },
  { icon: TrendingUp, title: 'Progress Tracking', desc: 'Monitor your improvement' },
];

export default function HomeScreen() {
  const router = useRouter();
  const pulseValue = useSharedValue(1);
  const shimmerValue = useSharedValue(-1);

  useEffect(() => {
    pulseValue.value = withRepeat(
      withSequence(
        withSpring(1.05, { duration: 1000 }),
        withSpring(1, { duration: 1000 })
      ),
      -1,
      true
    );

    shimmerValue.value = withRepeat(
      withSpring(1, { duration: 2000 }),
      -1,
      true
    );
  }, []);

  const pulseStyle = useAnimatedStyle(() => ({
    transform: [{ scale: pulseValue.value }],
  }));

  const shimmerStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: shimmerValue.value * (width + 100) }],
  }));

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#1F2937', '#374151', '#4B5563']}
        style={styles.gradient}>
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
          
          {/* Header */}
          <Animated.View entering={FadeInDown.delay(100)} style={styles.header}>
            <View style={styles.headerContent}>
              <Text style={styles.greeting}>Good Morning!</Text>
              <Text style={styles.username}>Ready to learn?</Text>
            </View>
            <TouchableOpacity style={styles.profileButton}>
              <LinearGradient
                colors={['#00D4AA', '#4ECDC4']}
                style={styles.profileGradient}>
                <Text style={styles.profileInitial}>U</Text>
              </LinearGradient>
            </TouchableOpacity>
          </Animated.View>

          {/* Hero Section */}
          <Animated.View entering={FadeInUp.delay(200)} style={styles.heroSection}>
            <LinearGradient
              colors={['#00D4AA', '#4ECDC4', '#7FDBDA']}
              style={styles.heroCard}>
              <View style={styles.heroOverlay}>
                <Animated.View style={[styles.shimmerContainer, shimmerStyle]}>
                  <LinearGradient
                    colors={['transparent', 'rgba(255,255,255,0.3)', 'transparent']}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                    style={styles.shimmerGradient}
                  />
                </Animated.View>
                <View style={styles.heroContent}>
                  <Text style={styles.heroTitle}>A New Language{'\n'}for a New Human</Text>
                  <Text style={styles.heroSubtitle}>Master pronunciation, understand differences, learn linguistic rules</Text>
                  <Animated.View style={pulseStyle}>
                    <TouchableOpacity 
                      style={styles.ctaButton}
                      onPress={() => router.push('/lessons')}>
                      <LinearGradient
                        colors={['#FFFFFF', '#F3F4F6']}
                        style={styles.ctaGradient}>
                        <Play size={20} color="#00D4AA" strokeWidth={2} />
                        <Text style={styles.ctaText}>Start Learning</Text>
                      </LinearGradient>
                    </TouchableOpacity>
                  </Animated.View>
                </View>
              </View>
            </LinearGradient>
          </Animated.View>

          {/* Stats Section */}
          <Animated.View entering={FadeInDown.delay(300)} style={styles.statsSection}>
            <View style={styles.statsGrid}>
              <View style={styles.statCard}>
                <LinearGradient colors={['#F8F9FA', '#E9ECEF']} style={styles.statGradient}>
                  <Star size={24} color="#00D4AA" strokeWidth={2} />
                  <Text style={styles.statNumber}>4.9</Text>
                  <Text style={styles.statLabel}>Rating</Text>
                </LinearGradient>
              </View>
              <View style={styles.statCard}>
                <LinearGradient colors={['#F8F9FA', '#E9ECEF']} style={styles.statGradient}>
                  <Clock size={24} color="#00D4AA" strokeWidth={2} />
                  <Text style={styles.statNumber}>15min</Text>
                  <Text style={styles.statLabel}>Daily</Text>
                </LinearGradient>
              </View>
              <View style={styles.statCard}>
                <LinearGradient colors={['#F8F9FA', '#E9ECEF']} style={styles.statGradient}>
                  <Users size={24} color="#00D4AA" strokeWidth={2} />
                  <Text style={styles.statNumber}>2M+</Text>
                  <Text style={styles.statLabel}>Learners</Text>
                </LinearGradient>
              </View>
            </View>
          </Animated.View>

          {/* Featured Languages */}
          <Animated.View entering={FadeInDown.delay(400)} style={styles.section}>
            <Text style={styles.sectionTitle}>Popular Languages</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.languageScroll}>
              {languages.map((language, index) => (
                <TouchableOpacity key={language.name} style={styles.languageCard}>
                  <LinearGradient
                    colors={['#F8F9FA', '#E9ECEF']}
                    style={styles.languageGradient}>
                    <Text style={styles.languageFlag}>{language.flag}</Text>
                    <Text style={styles.languageName}>{language.name}</Text>
                    <Text style={styles.languageSpeakers}>{language.speakers}</Text>
                    <View style={[styles.difficultyBadge, 
                      language.difficulty === 'Beginner' ? styles.beginnerBadge :
                      language.difficulty === 'Intermediate' ? styles.intermediateBadge :
                      styles.advancedBadge
                    ]}>
                      <Text style={[styles.difficultyText,
                        language.difficulty === 'Beginner' ? styles.beginnerText :
                        language.difficulty === 'Intermediate' ? styles.intermediateText :
                        styles.advancedText
                      ]}>{language.difficulty}</Text>
                    </View>
                  </LinearGradient>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </Animated.View>

          {/* Features */}
          <Animated.View entering={FadeInDown.delay(500)} style={styles.section}>
            <Text style={styles.sectionTitle}>Why Choose Us</Text>
            <View style={styles.featuresGrid}>
              {features.map((feature, index) => (
                <View key={feature.title} style={styles.featureCard}>
                  <LinearGradient
                    colors={['#F8F9FA', '#E9ECEF']}
                    style={styles.featureGradient}>
                    <View style={styles.featureIcon}>
                      <feature.icon size={24} color="#00D4AA" strokeWidth={2} />
                    </View>
                    <Text style={styles.featureTitle}>{feature.title}</Text>
                    <Text style={styles.featureDesc}>{feature.desc}</Text>
                  </LinearGradient>
                </View>
              ))}
            </View>
          </Animated.View>

          <View style={styles.bottomPadding} />
        </ScrollView>
      </LinearGradient>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1F2937',
  },
  gradient: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 16,
    paddingBottom: 24,
  },
  headerContent: {
    flex: 1,
  },
  greeting: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#9CA3AF',
    marginBottom: 4,
  },
  username: {
    fontSize: 24,
    fontFamily: 'Poppins-Bold',
    color: '#FFFFFF',
  },
  profileButton: {
    borderRadius: 24,
    overflow: 'hidden',
  },
  profileGradient: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileInitial: {
    fontSize: 18,
    fontFamily: 'Poppins-Bold',
    color: '#FFFFFF',
  },
  heroSection: {
    marginBottom: 32,
  },
  heroCard: {
    borderRadius: 24,
    overflow: 'hidden',
    minHeight: 200,
  },
  heroOverlay: {
    flex: 1,
    padding: 24,
    position: 'relative',
    overflow: 'hidden',
  },
  shimmerContainer: {
    position: 'absolute',
    top: 0,
    left: -100,
    width: 100,
    height: '100%',
    zIndex: 1,
  },
  shimmerGradient: {
    flex: 1,
  },
  heroContent: {
    flex: 1,
    justifyContent: 'center',
    zIndex: 2,
  },
  heroTitle: {
    fontSize: 28,
    fontFamily: 'Poppins-Bold',
    color: '#FFFFFF',
    marginBottom: 12,
    lineHeight: 36,
  },
  heroSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#FFFFFF',
    opacity: 0.9,
    marginBottom: 24,
    lineHeight: 24,
  },
  ctaButton: {
    alignSelf: 'flex-start',
    borderRadius: 16,
    overflow: 'hidden',
  },
  ctaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 16,
    gap: 8,
  },
  ctaText: {
    fontSize: 16,
    fontFamily: 'Poppins-SemiBold',
    color: '#00D4AA',
  },
  statsSection: {
    marginBottom: 32,
  },
  statsGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  statCard: {
    flex: 1,
    borderRadius: 16,
    overflow: 'hidden',
  },
  statGradient: {
    padding: 20,
    alignItems: 'center',
    gap: 8,
  },
  statNumber: {
    fontSize: 20,
    fontFamily: 'Poppins-Bold',
    color: '#1F2937',
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Poppins-SemiBold',
    color: '#FFFFFF',
    marginBottom: 16,
  },
  languageScroll: {
    marginHorizontal: -20,
    paddingHorizontal: 20,
  },
  languageCard: {
    marginRight: 16,
    borderRadius: 16,
    overflow: 'hidden',
  },
  languageGradient: {
    padding: 20,
    alignItems: 'center',
    width: 140,
    gap: 8,
  },
  languageFlag: {
    fontSize: 32,
    marginBottom: 8,
  },
  languageName: {
    fontSize: 16,
    fontFamily: 'Poppins-SemiBold',
    color: '#1F2937',
  },
  languageSpeakers: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  difficultyBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    marginTop: 4,
  },
  beginnerBadge: {
    backgroundColor: '#D1FAE5',
  },
  intermediateBadge: {
    backgroundColor: '#FEF3C7',
  },
  advancedBadge: {
    backgroundColor: '#FEE2E2',
  },
  difficultyText: {
    fontSize: 10,
    fontFamily: 'Inter-SemiBold',
  },
  beginnerText: {
    color: '#065F46',
  },
  intermediateText: {
    color: '#92400E',
  },
  advancedText: {
    color: '#991B1B',
  },
  featuresGrid: {
    gap: 16,
  },
  featureCard: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  featureGradient: {
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  featureIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: '#E0F2FE',
    justifyContent: 'center',
    alignItems: 'center',
  },
  featureTitle: {
    fontSize: 16,
    fontFamily: 'Poppins-SemiBold',
    color: '#1F2937',
    flex: 1,
  },
  featureDesc: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    flex: 1,
  },
  bottomPadding: {
    height: 20,
  },
});