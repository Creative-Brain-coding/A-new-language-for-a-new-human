import { View, Text, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
import { StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Play, CircleCheck as CheckCircle, Lock, Star, Clock, Volume2, BookOpen } from 'lucide-react-native';
import Animated, { FadeInDown, FadeInUp } from 'react-native-reanimated';

const { width } = Dimensions.get('window');

const lessonCategories = [
  {
    id: 1,
    title: 'Pronunciation Basics',
    description: 'Master the fundamental sounds',
    icon: Volume2,
    color: ['#00D4AA', '#4ECDC4'],
    lessons: 12,
    completed: 8,
    difficulty: 'Beginner',
  },
  {
    id: 2,
    title: 'Language Differences',
    description: 'Compare linguistic structures',
    icon: BookOpen,
    color: ['#667EEA', '#764BA2'],
    lessons: 15,
    completed: 5,
    difficulty: 'Intermediate',
  },
  {
    id: 3,
    title: 'Grammar Rules',
    description: 'Understand linguistic patterns',
    icon: Star,
    color: ['#F093FB', '#F5576C'],
    lessons: 18,
    completed: 0,
    difficulty: 'Advanced',
  },
];

const recentLessons = [
  {
    id: 1,
    title: 'Spanish Pronunciation: Rolling R',
    progress: 75,
    duration: '8 min',
    completed: false,
  },
  {
    id: 2,
    title: 'French vs English Vowels',
    progress: 100,
    duration: '12 min',
    completed: true,
  },
  {
    id: 3,
    title: 'German Accent Patterns',
    progress: 45,
    duration: '15 min',
    completed: false,
  },
];

export default function LessonsScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#1F2937', '#374151', '#4B5563']}
        style={styles.gradient}>
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
          
          {/* Header */}
          <Animated.View entering={FadeInDown.delay(100)} style={styles.header}>
            <Text style={styles.title}>Your Lessons</Text>
            <Text style={styles.subtitle}>Continue your language journey</Text>
          </Animated.View>

          {/* Progress Overview */}
          <Animated.View entering={FadeInUp.delay(200)} style={styles.progressSection}>
            <LinearGradient
              colors={['#F8F9FA', '#E9ECEF']}
              style={styles.progressCard}>
              <View style={styles.progressHeader}>
                <Text style={styles.progressTitle}>Weekly Progress</Text>
                <Text style={styles.progressPercentage}>73%</Text>
              </View>
              <View style={styles.progressBarContainer}>
                <View style={styles.progressBarBackground} />
                <LinearGradient
                  colors={['#00D4AA', '#4ECDC4']}
                  style={[styles.progressBarFill, { width: '73%' }]}
                />
              </View>
              <Text style={styles.progressText}>5 of 7 lessons completed this week</Text>
            </LinearGradient>
          </Animated.View>

          {/* Lesson Categories */}
          <Animated.View entering={FadeInDown.delay(300)} style={styles.section}>
            <Text style={styles.sectionTitle}>Lesson Categories</Text>
            <View style={styles.categoriesGrid}>
              {lessonCategories.map((category, index) => (
                <Animated.View
                  key={category.id}
                  entering={FadeInDown.delay(350 + index * 100)}
                  style={styles.categoryCard}>
                  <TouchableOpacity>
                    <LinearGradient
                      colors={category.color}
                      style={styles.categoryGradient}>
                      <View style={styles.categoryOverlay}>
                        <View style={styles.categoryHeader}>
                          <View style={styles.categoryIconContainer}>
                            <category.icon size={24} color="#FFFFFF" strokeWidth={2} />
                          </View>
                          <View style={[styles.difficultyBadge, 
                            category.difficulty === 'Beginner' ? styles.beginnerBadge :
                            category.difficulty === 'Intermediate' ? styles.intermediateBadge :
                            styles.advancedBadge
                          ]}>
                            <Text style={[styles.difficultyText,
                              category.difficulty === 'Beginner' ? styles.beginnerText :
                              category.difficulty === 'Intermediate' ? styles.intermediateText :
                              styles.advancedText
                            ]}>{category.difficulty}</Text>
                          </View>
                        </View>
                        <Text style={styles.categoryTitle}>{category.title}</Text>
                        <Text style={styles.categoryDescription}>{category.description}</Text>
                        <View style={styles.categoryFooter}>
                          <Text style={styles.categoryStats}>{category.lessons} lessons</Text>
                          <Text style={styles.categoryProgress}>
                            {category.completed}/{category.lessons} completed
                          </Text>
                        </View>
                        <View style={styles.categoryProgressBar}>
                          <View style={styles.categoryProgressBackground} />
                          <View style={[
                            styles.categoryProgressFill,
                            { width: `${(category.completed / category.lessons) * 100}%` }
                          ]} />
                        </View>
                      </View>
                    </LinearGradient>
                  </TouchableOpacity>
                </Animated.View>
              ))}
            </View>
          </Animated.View>

          {/* Recent Lessons */}
          <Animated.View entering={FadeInDown.delay(600)} style={styles.section}>
            <Text style={styles.sectionTitle}>Continue Learning</Text>
            <View style={styles.recentLessons}>
              {recentLessons.map((lesson, index) => (
                <Animated.View
                  key={lesson.id}
                  entering={FadeInDown.delay(650 + index * 100)}
                  style={styles.lessonCard}>
                  <TouchableOpacity>
                    <LinearGradient
                      colors={['#F8F9FA', '#E9ECEF']}
                      style={styles.lessonGradient}>
                      <View style={styles.lessonContent}>
                        <View style={styles.lessonHeader}>
                          <View style={styles.lessonIcon}>
                            {lesson.completed ? (
                              <CheckCircle size={20} color="#00D4AA" strokeWidth={2} />
                            ) : (
                              <Play size={20} color="#00D4AA" strokeWidth={2} />
                            )}
                          </View>
                          <View style={styles.lessonMeta}>
                            <Text style={styles.lessonTitle}>{lesson.title}</Text>
                            <View style={styles.lessonDetails}>
                              <Clock size={14} color="#6B7280" strokeWidth={2} />
                              <Text style={styles.lessonDuration}>{lesson.duration}</Text>
                            </View>
                          </View>
                          <Text style={styles.lessonPercentage}>{lesson.progress}%</Text>
                        </View>
                        <View style={styles.lessonProgressContainer}>
                          <View style={styles.lessonProgressBackground} />
                          <LinearGradient
                            colors={lesson.completed ? ['#00D4AA', '#4ECDC4'] : ['#00D4AA', '#4ECDC4']}
                            style={[styles.lessonProgressFill, { width: `${lesson.progress}%` }]}
                          />
                        </View>
                      </View>
                    </LinearGradient>
                  </TouchableOpacity>
                </Animated.View>
              ))}
            </View>
          </Animated.View>

          <View style={styles.bottomPadding} />
        </ScrollView>
      </LinearGradient>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1F2937',
  },
  gradient: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 20,
  },
  header: {
    paddingTop: 16,
    paddingBottom: 24,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Poppins-Bold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
  },
  progressSection: {
    marginBottom: 32,
  },
  progressCard: {
    borderRadius: 20,
    padding: 24,
  },
  progressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  progressTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: '#1F2937',
  },
  progressPercentage: {
    fontSize: 24,
    fontFamily: 'Poppins-Bold',
    color: '#00D4AA',
  },
  progressBarContainer: {
    position: 'relative',
    height: 8,
    marginBottom: 12,
  },
  progressBarBackground: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    backgroundColor: '#E5E7EB',
    borderRadius: 4,
  },
  progressBarFill: {
    height: '100%',
    borderRadius: 4,
  },
  progressText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Poppins-SemiBold',
    color: '#FFFFFF',
    marginBottom: 16,
  },
  categoriesGrid: {
    gap: 16,
  },
  categoryCard: {
    borderRadius: 20,
    overflow: 'hidden',
  },
  categoryGradient: {
    minHeight: 160,
  },
  categoryOverlay: {
    flex: 1,
    padding: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.1)',
  },
  categoryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  categoryIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  difficultyBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  beginnerBadge: {
    backgroundColor: 'rgba(209, 250, 229, 0.9)',
  },
  intermediateBadge: {
    backgroundColor: 'rgba(254, 243, 199, 0.9)',
  },
  advancedBadge: {
    backgroundColor: 'rgba(254, 226, 226, 0.9)',
  },
  difficultyText: {
    fontSize: 10,
    fontFamily: 'Inter-SemiBold',
  },
  beginnerText: {
    color: '#065F46',
  },
  intermediateText: {
    color: '#92400E',
  },
  advancedText: {
    color: '#991B1B',
  },
  categoryTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  categoryDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#FFFFFF',
    opacity: 0.9,
    marginBottom: 16,
  },
  categoryFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  categoryStats: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#FFFFFF',
    opacity: 0.8,
  },
  categoryProgress: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#FFFFFF',
    opacity: 0.8,
  },
  categoryProgressBar: {
    position: 'relative',
    height: 4,
  },
  categoryProgressBackground: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    borderRadius: 2,
  },
  categoryProgressFill: {
    height: '100%',
    backgroundColor: '#FFFFFF',
    borderRadius: 2,
  },
  recentLessons: {
    gap: 12,
  },
  lessonCard: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  lessonGradient: {
    padding: 16,
  },
  lessonContent: {
    gap: 12,
  },
  lessonHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  lessonIcon: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: '#E0F2FE',
    justifyContent: 'center',
    alignItems: 'center',
  },
  lessonMeta: {
    flex: 1,
    gap: 4,
  },
  lessonTitle: {
    fontSize: 16,
    fontFamily: 'Poppins-SemiBold',
    color: '#1F2937',
  },
  lessonDetails: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  lessonDuration: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  lessonPercentage: {
    fontSize: 14,
    fontFamily: 'Poppins-SemiBold',
    color: '#00D4AA',
  },
  lessonProgressContainer: {
    position: 'relative',
    height: 6,
  },
  lessonProgressBackground: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    backgroundColor: '#E5E7EB',
    borderRadius: 3,
  },
  lessonProgressFill: {
    height: '100%',
    borderRadius: 3,
  },
  bottomPadding: {
    height: 20,
  },
});